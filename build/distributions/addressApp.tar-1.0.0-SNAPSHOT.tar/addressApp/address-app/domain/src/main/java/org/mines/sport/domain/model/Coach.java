package org.mines.sport.domain.model;

import java.util.List;

public class Coach {
    private Person individual;
    private List<Sports> coachingSport;
}
