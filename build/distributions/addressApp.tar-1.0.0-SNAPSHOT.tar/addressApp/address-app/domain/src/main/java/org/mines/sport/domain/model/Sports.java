package org.mines.sport.domain.model;

public class Sports {

    private String nameSport;
    private boolean teamsSport;
    private boolean contactSport;
}
