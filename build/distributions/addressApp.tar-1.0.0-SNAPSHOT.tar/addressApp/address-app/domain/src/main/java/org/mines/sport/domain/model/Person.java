package org.mines.sport.domain.model;

import java.util.List;

public class Person {

    private String name;
    private float weight;
    private float tall;
    private List<Sports> practicateSports;
}
